﻿/*
********************************************************************************
* COPYRIGHT(c) ЗАО «ЧИП и ДИП», 2018
* 
* Программное обеспечение предоставляется на условиях «как есть» (as is).
* При распространении указание автора обязательно.
********************************************************************************
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LogicAnalyzer
{
    class MatchingItem : InterfaceItem
    {
        public int ItemIndex { get; set; }
    }
}
